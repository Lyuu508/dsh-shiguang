import { readFileSync, mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, resolve } from 'node:path';
import { homedir } from 'node:os';

export const MEDIA_DEFAULTS = {
  enabled: false, mode: 'ask' as 'ask' | 'auto', provider: '', model: '',
  ffmpegPath: 'ffmpeg', ffprobePath: 'ffprobe', localMediaDir: '',
  frames: 3, sheetSize: 512, maxFileMB: 20, maxDurationSeconds: 120,
  timeoutMs: 30000, maxOutputTokens: 320, dailyLimit: 30, contextChars: 600, cacheHours: 24,
};
export type MediaSettings = typeof MEDIA_DEFAULTS;

export interface Settings {
  roleId: string; displayName: string; persona: string; timezone: string; dataDir: string;
  provider: string; model: string; replyTimeoutMs: number; maxReplyChars: number; maxQueue: number;
  memory: { todayMaxChars: number; recentMessages: number; recentMaxChars: number; searchLimit: number; snippetChars: number; detailMaxChars: number };
  media: MediaSettings;
  qq: { enabled: boolean; wsUrl: string; tokenEnv: string; ownerQQ: string; allowedPrivate: string[]; allowedGroups: string[]; groupMentionOnly: boolean; actionTimeoutMs: number; reconnectMs: number };
  bilibili: { enabled: boolean; allowComments: boolean; commentsPerDay: number; minCommentIntervalMs: number; timeoutMs: number };
}

function object(v: unknown, key: string): Record<string, unknown> {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error(`配置 ${key} 必须是对象`);
  return v as Record<string, unknown>;
}
function string(v: unknown, key: string): string {
  if (typeof v !== 'string') throw new Error(`配置 ${key} 必须是字符串`);
  return v;
}
function boolean(v: unknown, key: string): boolean {
  if (typeof v !== 'boolean') throw new Error(`配置 ${key} 必须是布尔值`);
  return v;
}
function integer(v: unknown, key: string, min: number, max: number): number {
  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < min || v > max) throw new Error(`配置 ${key} 应在 ${min}–${max} 之间`);
  return v;
}
function ids(v: unknown, key: string): string[] {
  if (!Array.isArray(v) || v.some(x => typeof x !== 'string' || !/^\d+$/.test(x))) throw new Error(`配置 ${key} 应为 QQ 号码字符串数组`);
  return v as string[];
}
export function configFile(path = ''): string {
  return resolve(path || process.env.DSH_SHIGUANG_CONFIG || resolve(homedir(), '.dsh', 'shiguang', 'config.json'));
}
export function parseSettings(value: unknown, file: string): Settings {
  const c = object(value, 'root'), m = object(c.memory, 'memory'), q = object(c.qq, 'qq'), b = object(c.bilibili, 'bilibili');
  const v = { ...MEDIA_DEFAULTS, ...(c.media === undefined ? {} : object(c.media,'media')) };
  const zone = string(c.timezone, 'timezone');
  const timezone = zone === 'system' ? Intl.DateTimeFormat().resolvedOptions().timeZone : zone;
  new Intl.DateTimeFormat('en', { timeZone: timezone }).format();
  const dataPath = string(c.dataDir, 'dataDir');
  const s: Settings = {
    roleId: string(c.roleId, 'roleId'), displayName: string(c.displayName ?? '拾光', 'displayName'), persona: string(c.persona, 'persona'), timezone,
    dataDir: isAbsolute(dataPath) ? dataPath : resolve(dirname(file), dataPath),
    provider: string(c.provider, 'provider'), model: string(c.model, 'model'),
    replyTimeoutMs: integer(c.replyTimeoutMs, 'replyTimeoutMs', 1000, 600000),
    maxReplyChars: integer(c.maxReplyChars, 'maxReplyChars', 100, 10000), maxQueue: integer(c.maxQueue, 'maxQueue', 1, 100),
    memory: {
      todayMaxChars: integer(m.todayMaxChars, 'memory.todayMaxChars', 100, 20000),
      recentMessages: integer(m.recentMessages, 'memory.recentMessages', 1, 100),
      recentMaxChars: integer(m.recentMaxChars, 'memory.recentMaxChars', 100, 20000),
      searchLimit: integer(m.searchLimit, 'memory.searchLimit', 1, 20),
      snippetChars: integer(m.snippetChars, 'memory.snippetChars', 50, 1000),
      detailMaxChars: integer(m.detailMaxChars, 'memory.detailMaxChars', 100, 10000),
    },
    media: {
      enabled: boolean(v.enabled,'media.enabled'), mode: string(v.mode,'media.mode') as MediaSettings['mode'],
      provider: string(v.provider,'media.provider'), model: string(v.model,'media.model'),
      ffmpegPath: string(v.ffmpegPath,'media.ffmpegPath'), ffprobePath: string(v.ffprobePath,'media.ffprobePath'), localMediaDir: string(v.localMediaDir,'media.localMediaDir'),
      frames: integer(v.frames,'media.frames',1,6), sheetSize: integer(v.sheetSize,'media.sheetSize',256,1024),
      maxFileMB: integer(v.maxFileMB,'media.maxFileMB',1,50), maxDurationSeconds: integer(v.maxDurationSeconds,'media.maxDurationSeconds',1,600),
      timeoutMs: integer(v.timeoutMs,'media.timeoutMs',1000,120000), maxOutputTokens: integer(v.maxOutputTokens,'media.maxOutputTokens',128,1024),
      dailyLimit: integer(v.dailyLimit,'media.dailyLimit',0,200), contextChars: integer(v.contextChars,'media.contextChars',0,2000), cacheHours: integer(v.cacheHours,'media.cacheHours',1,168),
    },
    qq: {
      enabled: boolean(q.enabled, 'qq.enabled'), wsUrl: string(q.wsUrl, 'qq.wsUrl'), tokenEnv: string(q.tokenEnv, 'qq.tokenEnv'),
      ownerQQ: string(q.ownerQQ, 'qq.ownerQQ'), allowedPrivate: ids(q.allowedPrivate, 'qq.allowedPrivate'), allowedGroups: ids(q.allowedGroups, 'qq.allowedGroups'),
      groupMentionOnly: boolean(q.groupMentionOnly, 'qq.groupMentionOnly'),
      actionTimeoutMs: integer(q.actionTimeoutMs, 'qq.actionTimeoutMs', 1000, 120000), reconnectMs: integer(q.reconnectMs, 'qq.reconnectMs', 500, 60000),
    },
    bilibili: {
      enabled: boolean(b.enabled, 'bilibili.enabled'), allowComments: boolean(b.allowComments, 'bilibili.allowComments'),
      commentsPerDay: integer(b.commentsPerDay, 'bilibili.commentsPerDay', 0, 100),
      minCommentIntervalMs: integer(b.minCommentIntervalMs, 'bilibili.minCommentIntervalMs', 1000, 86400000),
      timeoutMs: integer(b.timeoutMs, 'bilibili.timeoutMs', 1000, 120000),
    },
  };
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(s.roleId)) throw new Error('roleId 只能使用字母、数字、下划线和连字符');
  if (!s.displayName.trim() || s.displayName.length > 40 || s.persona.length > 20000) throw new Error('角色名称应为 1–40 字，人设最多 20000 字');
  if (Boolean(s.provider) !== Boolean(s.model)) throw new Error('provider 和 model 必须同时填写或同时留空，留空使用 DSH 默认模型');
  if (!['ask','auto'].includes(s.media.mode) || ![256,512,768,1024].includes(s.media.sheetSize)) throw new Error('视频识别模式或拼图尺寸无效');
  if (Boolean(s.media.provider) !== Boolean(s.media.model)) throw new Error('视觉模型的 provider 和 model 必须同时填写或同时留空');
  if ([s.media.ffmpegPath,s.media.ffprobePath].some(p=>!p.trim() || /[\r\n\0]/.test(p))) throw new Error('请填写有效的 FFmpeg / FFprobe 程序路径');
  const u = new URL(s.qq.wsUrl);
  if (!['ws:', 'wss:'].includes(u.protocol) || u.username || u.password || u.search || u.hash) throw new Error('qq.wsUrl 必须为不带凭据或查询参数的 ws/wss 地址');
  if (s.qq.enabled && !/^\d+$/.test(s.qq.ownerQQ)) throw new Error('启用 QQ 前，请设置 ownerQQ');
  if (s.qq.tokenEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(s.qq.tokenEnv)) throw new Error('Token 环境变量名称无效');
  return s;
}
export function ensureSettings(path = ''): string {
  const file = configFile(path);
  if (!existsSync(file)) {
    mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
    writeFileSync(file, readFileSync(new URL('../config.example.json', import.meta.url)), { flag: 'wx', mode: 0o600 });
  }
  return file;
}
export function loadSettings(path = ''): Settings {
  const file = configFile(path);
  let text: string;
  try { text = readFileSync(file, 'utf8'); } catch { throw new Error(`尚未配置 Shiguang。请在插件目录执行 npm run setup，配置文件：${file}`); }
  const settings = parseSettings(JSON.parse(text), file);
  mkdirSync(settings.dataDir, { recursive: true, mode: 0o700 });
  return settings;
}
