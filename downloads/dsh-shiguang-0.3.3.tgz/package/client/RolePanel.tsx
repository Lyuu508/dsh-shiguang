import {SettingSection} from './CompactSettings.js';
import React,{useState} from 'react';
import type {PanelApi,Snapshot} from './types.js';
import {Field,Toggle} from './Form.js';
export function RolePanel({api,snapshot,dirty,onAccept}:{api:PanelApi;snapshot:Snapshot;dirty:boolean;onAccept:(s:Snapshot)=>void}){
 const [name,setName]=useState(''),[persona,setPersona]=useState(''),[copy,setCopy]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function action(kind:'role-create'|'role-switch',id=''){setBusy(true);setError('');try{const s=await api.call<Snapshot>(kind,{id,name,persona,copy,revision:snapshot.revision});onAccept(s);setName('');setPersona('');}catch(e){setError(e instanceof Error?e.message:'角色操作未完成');}finally{setBusy(false);}}
 return <SettingSection className="sg-section"><h2>角色档案</h2><Field label="当前角色"><select disabled={busy||dirty} value={snapshot.settings.roleId} onChange={e=>void action('role-switch',e.target.value)}>{snapshot.roles.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></Field><p className="sg-help">角色分别保留人设、声音、记忆和生物钟；模型统一使用最新 Flash；QQ / B 站连接沿用当前账号。切换不会删除旧角色记忆，同一角色内主人 QQ 与 B 站共用历史。</p><details><summary>新建另一个角色</summary><Field label="新角色名字"><input value={name} onChange={e=>setName(e.target.value)}/></Field><Field label="新角色人设"><textarea rows={4} value={persona} onChange={e=>setPersona(e.target.value)}/></Field><Toggle label="复制当前角色的设置" value={copy} onChange={setCopy}/><button disabled={dirty||busy||!name.trim()} className="sg-primary" onClick={()=>void action('role-create')}>新建并切换角色</button></details>{dirty&&<p className="sg-help">请先保存当前修改，再切换或新建角色。</p>}{error&&<p className="sg-notice error" role="alert">{error}</p>}</SettingSection>;
}
